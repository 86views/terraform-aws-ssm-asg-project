exports.handler = async (event) => {
  const https = require('https');
  const message = event.Records[0].Sns.Message;
  
  const data = JSON.stringify({
    text: '🚨 AWS Alert: ' + message
  });
  
  const url = new URL(process.env.SLACK_WEBHOOK_URL);
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    }
  };
  
  return new Promise((resolve) => {
    const req = https.request(options, (res) => {
      resolve({ statusCode: res.statusCode });
    });
    req.write(data);
    req.end();
  });
};
